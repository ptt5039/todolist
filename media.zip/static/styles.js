(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["styles"],{

/***/ "./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./src/styles.css":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src??embedded!./src/styles.css ***!
  \*****************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = [[module.i, ".register-wrapper {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    height: 100vh;\n}\n  \n.register-wrapper h1{\n    font-size: 100px;\n    font-weight: 100;\n    text-align: center;\n    color: rgba(175, 47, 47, 0.15);\n    -webkit-text-rendering: optimizeLegibility;\n    -moz-text-rendering: optimizeLegibility;\n    text-rendering: optimizeLegibility;\n}\n  \n.register-wrapper input {\n    display: block;\n    width: 100%;\n    padding: 16px;\n    border: none;\n    background: rgba(0, 0, 0, 0.003);\n    box-shadow: inset 0 -2px 1px rgba(0, 0, 0, 0.03);\n    margin: 0 0 16px 0;\n    font-size: 20px;\n    border-left: 2px solid transparent;\n}\n  \n.register-wrapper input::-webkit-input-placeholder {\n    font-style: italic;\n    font-weight: 300;\n    color: rgba(0, 0, 0, 0.5);\n}\n  \n.register-wrapper button {\n    display: block;\n    background-color: rgba(175, 47, 47, 0.15);\n    width: 100%;\n    padding: 16px;\n    font-size: 20px;\n    cursor: pointer;\n    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n    margin-bottom: 64px;\n}\n  \n.sign-in-wrapper {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    height: 100vh;\n}\n  \n.sign-in-wrapper h1{\n    font-size: 100px;\n    font-weight: 100;\n    text-align: center;\n    color: rgba(175, 47, 47, 0.15);\n    -webkit-text-rendering: optimizeLegibility;\n    -moz-text-rendering: optimizeLegibility;\n    text-rendering: optimizeLegibility;\n}\n  \n.sign-in-wrapper input {\n    display: block;\n    width: 100%;\n    padding: 16px;\n    border: none;\n    background: rgba(0, 0, 0, 0.003);\n    box-shadow: inset 0 -2px 1px rgba(0, 0, 0, 0.03);\n    margin: 0 0 16px 0;\n    font-size: 20px;\n    border-left: 2px solid transparent;\n}\n  \n.sign-in-wrapper input::-webkit-input-placeholder {\n    font-style: italic;\n    font-weight: 300;\n    color: rgba(0, 0, 0, 0.5);\n}\n  \n.sign-in-wrapper button {\n    display: block;\n    background-color: rgba(175, 47, 47, 0.15);\n    width: 100%;\n    padding: 16px;\n    font-size: 20px;\n    cursor: pointer;\n    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n    margin-bottom: 64px;\n}\n  \n.todoapp {\n\tbackground: #fff;\n\tmargin: 150px 50px 40px 50px;\n\tposition: relative;\n\tbox-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2),\n\t            0 25px 50px 0 rgba(0, 0, 0, 0.1);\n}\n  \n.todoapp .task-button {\n\t\tcursor: pointer;\n\t\tmargin: 10px;\n\t\tpadding: 5px;\n\t\tborder: 0;\n\t\tbackground: none;\n\t\tfont-size: 100%;\n\t\tvertical-align: baseline;\n\t\tfont-family: inherit;\n\t\tfont-weight: inherit;\n\t\tcolor: inherit;\n\t\t-webkit-appearance: none;\n\t\t-moz-appearance: none;\n\t\t     appearance: none;\n\t\t-webkit-font-smoothing: antialiased;\n\t\t-moz-osx-font-smoothing: grayscale;\n\t\tbackground-color: rgba(175, 47, 47, 0.15);\n\t\tbox-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n}\n  \n.todoapp .input input::-webkit-input-placeholder {\n\tfont-style: italic;\n\tfont-weight: 300;\n\tcolor: #e6e6e6;\n}\n  \n.todoapp .input h1 {\n\tposition: absolute;\n\tdisplay:block;\n\tmargin-left: 40%;\n\tmargin-right: auto;\n\tmargin-top: -150px;\n\tfont-size: 100px;\n\tfont-weight: 100;\n\tcolor: rgba(175, 47, 47, 0.15);\n\t-webkit-text-rendering: optimizeLegibility;\n\t-moz-text-rendering: optimizeLegibility;\n\ttext-rendering: optimizeLegibility;\n}\n  \n.todoapp h1.editing {\n\tdisplay: none;\n}\n  \n.new-todo,\n.edit {\n\tposition: relative;\n\tmargin: 0;\n\twidth: 100%;\n\tfont-size: 28px;\n\tfont-family: inherit;\n\tfont-weight: inherit;\n\tline-height: 1.4em;\n\tborder: 0;\n\tcolor: inherit;\n\tpadding: 6px;\n\tborder: 1px solid #999;\n\tbox-shadow: inset 0 -1px 5px 0 rgba(0, 0, 0, 0.2);\n\tbox-sizing: border-box;\n\t-webkit-font-smoothing: antialiased;\n\t-moz-osx-font-smoothing: grayscale;\n}\n  \n.new-todo {\n\tpadding: 16px 16px 16px 60px;\n\tborder: none;\n\tbackground: rgba(0, 0, 0, 0.003);\n\tbox-shadow: inset 0 -2px 1px rgba(0,0,0,0.03);\n}\n  \n.main {\n\tposition: relative;\n\tz-index: 2;\n\tborder-top: 1px solid #e6e6e6;\n}\n  \n.todo-list {\n\tmargin: 0;\n\tpadding: 0;\n\tlist-style: none;\n}\n  \n.todo-list li {\n\tposition: relative;\n\tfont-size: 28px;\n\tborder-bottom: 1px solid #ededed;\n}\n  \n.todo-list li:last-child {\n\tborder-bottom: none;\n}\n  \n.todo-list li.editing {\n\tborder-bottom: none;\n\tpadding: 0;\n\tfont-size: 21px;\n}\n  \n.todo-list li.editing .edit {\n\tdisplay: block;\n\twidth: 650px;\n\tpadding: 12px 16px;\n\tmargin: 0 0 0 43px;\n}\n  \n.todo-list li .toggle {\n\t-webkit-appearance: none;\n     -moz-appearance: none;\n     appearance: none;\n     display: inline-block;\n     position: absolute;\n     background-color: #f1f1f1;\n     color: #666;\n\t top: 15px;\n\t left: 20px;\n     height: 40px;\n     width: 40px;\n     border: 0;\n\t border-radius: 70px;\n     cursor: pointer; \n     outline: none;\n}\n  \n.todo-list li .toggle:checked {\n\tbackground-color: #f1f1f1;\n}\n  \n.todo-list li .toggle:hover\n{\n     background-color: #f7f7f7;\n}\n  \n.todo-list li .toggle:checked::before {\n\tposition: absolute;\n\tfont: 35px 'Open Sans', sans-serif;\n\tfont-weight: bolder;\n\tleft: 9px;\n\ttop: -3px;\n    content: '\\02143';\n    -webkit-transform: rotate(40deg);\n            transform: rotate(40deg);\n}\n  \n.todo-list li label {\n\tword-break: break-all;\n\tpadding: 15px 60px 15px 15px;\n\tmargin-left: 65px;\n\tdisplay: block;\n\tline-height: 1.2;\n\ttransition: color 0.4s;\n}\n  \n.todo-list li.completed label {\n\tcolor: #d9d9d9;\n\ttext-decoration: line-through;\n}\n  \n.todo-list li .destroy {\n\tdisplay: none;\n\tposition: absolute;\n\ttop: 0;\n\tright: 10px;\n\tbottom: 0;\n\twidth: 40px;\n\theight: 40px;\n\tmargin: 0;\n\tfont-size: 45px;\n\tcolor: #cc9a9a;\n\tmargin-bottom: 11px;\n\ttransition: color 0.2s ease-out;\n}\n  \n.todo-list li .destroy:hover {\n\tcolor: #af5b5e;\n}\n  \n.todo-list li .destroy:after {\n\tcontent: '×';\n}\n  \n.todo-list li:hover .destroy {\n\tdisplay: block;\n}\n  \n.todo-list .edit {\n\tdisplay: none;\n}\n  \n.footer {\n\tcolor: #777;\n\tpadding: 10px 15px;\n\theight: 50px;\n\ttext-align: center;\n\tborder-top: 1px solid #e6e6e6;\n}\n  \n.footer:before {\n\tcontent: '';\n\tposition: absolute;\n\tright: 0;\n\tbottom: 0;\n\tleft: 0;\n\theight: 50px;\n\toverflow: hidden;\n\tbox-shadow: 0 1px 1px rgba(0, 0, 0, 0.2),\n\t            0 8px 0 -3px #f6f6f6,\n\t            0 9px 1px -3px rgba(0, 0, 0, 0.2),\n\t            0 16px 0 -6px #f6f6f6,\n\t            0 17px 2px -6px rgba(0, 0, 0, 0.2);\n}\n  \n.todo-count {\n\tfloat: left;\n\ttext-align: left;\n}\n  \n.todo-count strong {\n\tfont-weight: 300;\n}\n  \n.sign-out {\n\tdisplay: block;\n\tposition: relative;\n\tbackground-color: rgba(175, 47, 47, 0.15);\n\tpadding: 14px 100px;\n\tmargin: 100px auto;\n\tfont-size: 20px;\n\tcursor: pointer;\n\tborder: 0;\n\tcolor: inherit;\n\tbox-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n}\n  \n.todo-list button {\n\tmargin: 0;\n\tpadding: 0;\n\tborder: 0;\n\tbackground: none;\n\tfont-size: 100%;\n\tvertical-align: baseline;\n\tfont-family: inherit;\n\tfont-weight: inherit;\n\tcolor: inherit;\n\t-webkit-appearance: none;\n\t-moz-appearance: none;\n\t     appearance: none;\n\t-webkit-font-smoothing: antialiased;\n\t-moz-osx-font-smoothing: grayscale;\n}\n  \n.profile {\n    background: #fff;\n    margin: 50px 50px 40px 50px;\n    position: relative;\n    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2),\n                0 25px 50px 0 rgba(0, 0, 0, 0.1);\n}\n  \n.profile .input{\n    margin: 10px;\n}\n  \n.profile .input h1 {\n\tposition: relative;\n\twidth: 100%;\n\tfont-size: 100px;\n\tfont-weight: 100;\n\tcolor: rgba(175, 47, 47, 0.15);\n\t-webkit-text-rendering: optimizeLegibility;\n\t-moz-text-rendering: optimizeLegibility;\n\ttext-rendering: optimizeLegibility;\n}\n  \n.profile button {\n    cursor: pointer;\n\tmargin: 10px;\n\tpadding: 5px;\n\tborder: 0;\n\tbackground: none;\n\tfont-size: 100%;\n\tvertical-align: baseline;\n\tfont-family: inherit;\n\tfont-weight: inherit;\n\tcolor: inherit;\n\t-webkit-appearance: none;\n\t-moz-appearance: none;\n\t     appearance: none;\n\t-webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n    background-color: rgba(175, 47, 47, 0.15);\n    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n}\n  \n.creator-display {\n\tmargin-left: 50px;\n}\n  \n.nav {\n    float: right;\n\tmargin-top: -50px;\n\tmargin-right: 40px;\n}\n  \n.nav button {\n    cursor: pointer;\n\tmargin: 10px;\n\tpadding: 5px;\n\tborder: 0;\n\tbackground: none;\n\tfont-size: 100%;\n\tvertical-align: baseline;\n\tfont-family: inherit;\n\tfont-weight: inherit;\n\tcolor: inherit;\n\t-webkit-appearance: none;\n\t-moz-appearance: none;\n\t     appearance: none;\n\t-webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n    background-color: rgba(175, 47, 47, 0.15);\n    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n}\n  \n.nav p {\n    margin: 15px 5px;\n    text-align: right;\n}\n  \n.task {\n\tmargin-left: 10px;\n\tmargin-right: 10px;\n}\n  \n.task .image-field{\n\tpadding-right:3px; \n\tpadding-top: 3px; \n\tdisplay: inline-block;\n\tposition: relative;\n\tmargin:30px;\n\t\n}\n  \n.task img{\n\tdisplay: block;\n\tmargin-left: auto; \n\tmargin-right: auto; \n\theight: 250px;\n\twidth: 250px;\n\tcursor: pointer;\n\t\n}\n  \n.task img:hover {\n\topacity: 0.7;\n}\n  \n.modal {\n\tdisplay:block;\n  \tposition: fixed; /* Stay in place */\n  \tz-index: 1; /* Sit on top */\n  \tpadding-top: 100px; /* Location of the box */\n  \tmargin: auto;\n  \twidth: 95%;\n  \theight: 95%;\n  \toverflow: auto; /* Enable scroll if needed */\n  \tbackground-color: rgb(0,0,0); /* Fallback color */\n  \tbackground-color: rgba(0,0,0,0.9); /* Black w/ opacity */\n}\n  \n.modal-content {\n\tmargin: auto;\n\tdisplay: block;\n\twidth: 90%;\n\tmax-width: 700px;\n}\n  \n.close {\n\tposition: absolute;\n\ttop: 15px;\n\tright: 35px;\n\tcolor: #f1f1f1;\n\tfont-size: 40px;\n\tfont-weight: bold;\n\ttransition: 0.3s;\n  }\n  \n.close:hover,\n.close:focus {\n\tcolor: #bbb;\n\ttext-decoration: none;\n\tcursor: pointer;\n}\n  \n.delete {\n\tposition: absolute;\n\ttop: 10px;\n\tmargin-left: 210px;\n\tmargin-top: -30px;\n\tcolor: #f32a2a;\n\tfont-size: 50px;\n\tfont-weight: bold;\n\ttransition: 0.3s;\n  }\n  \n.delete:hover,\n.delete:focus {\n\tcolor: rgb(151, 2, 2);\n\ttext-decoration: none;\n\tcursor: pointer;\n}\n  \n.delete-alert {\n\tdisplay:block;\n  \tposition: fixed; /* Stay in place */\n  \tz-index: 1; /* Sit on top */\n  \tpadding-top: 20px; /* Location of the box */\n\tmargin-left: 15%;\n\tmargin-right: auto;\n\tmargin-top: -20px;\n  \twidth: 500px;\n  \theight: 200px;\n\tbackground-color: rgb(255, 251, 251); /* Fallback color */\n\tbox-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n\n}\n  \n.delete-alert p {\n\tmargin-left: 15px;\n\tfont-size: 30px;\n\tcolor: rgb(207, 29, 29);\n\n}\n  \n.delete-alert button{\n\tcursor: pointer;\n\tpadding: 0 10px 0 10px;\n\tborder: 0;\n\tmargin: 15px;\n\tbackground: none;\n\tfont-size: 150%;\n\tvertical-align: baseline;\n\tfont-family: inherit;\n\tfont-weight: bold;\n\tcolor: inherit;\n\t-webkit-appearance: none;\n\t-moz-appearance: none;\n\t     appearance: none;\n\t-webkit-font-smoothing: antialiased;\n\t-moz-osx-font-smoothing: grayscale;\n\tbackground-color: rgba(175, 47, 47, 0.15);\n\tbox-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);\n}\n  \n.delete-alert .buttons {\n\tdisplay: flex;\n\tmargin-top: 35px;\n\tjustify-content: space-evenly;\n\t\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9zdHlsZXMuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLG9CQUFvQjtJQUNwQix3QkFBd0I7SUFDeEIsY0FBYztDQUNqQjs7QUFFRDtJQUNJLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsbUJBQW1CO0lBQ25CLCtCQUErQjtJQUMvQiwyQ0FBMkM7SUFDM0Msd0NBQXdDO0lBQ3hDLG1DQUFtQztDQUN0Qzs7QUFFRDtJQUNJLGVBQWU7SUFDZixZQUFZO0lBQ1osY0FBYztJQUNkLGFBQWE7SUFDYixpQ0FBaUM7SUFDakMsaURBQWlEO0lBQ2pELG1CQUFtQjtJQUNuQixnQkFBZ0I7SUFDaEIsbUNBQW1DO0NBQ3RDOztBQUVEO0lBQ0ksbUJBQW1CO0lBQ25CLGlCQUFpQjtJQUNqQiwwQkFBMEI7Q0FDN0I7O0FBRUQ7SUFDSSxlQUFlO0lBQ2YsMENBQTBDO0lBQzFDLFlBQVk7SUFDWixjQUFjO0lBQ2QsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtJQUNoQiw2RUFBNkU7SUFDN0Usb0JBQW9CO0NBQ3ZCOztBQUVEO0lBQ0ksY0FBYztJQUNkLG9CQUFvQjtJQUNwQix3QkFBd0I7SUFDeEIsY0FBYztDQUNqQjs7QUFFRDtJQUNJLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsbUJBQW1CO0lBQ25CLCtCQUErQjtJQUMvQiwyQ0FBMkM7SUFDM0Msd0NBQXdDO0lBQ3hDLG1DQUFtQztDQUN0Qzs7QUFFRDtJQUNJLGVBQWU7SUFDZixZQUFZO0lBQ1osY0FBYztJQUNkLGFBQWE7SUFDYixpQ0FBaUM7SUFDakMsaURBQWlEO0lBQ2pELG1CQUFtQjtJQUNuQixnQkFBZ0I7SUFDaEIsbUNBQW1DO0NBQ3RDOztBQUVEO0lBQ0ksbUJBQW1CO0lBQ25CLGlCQUFpQjtJQUNqQiwwQkFBMEI7Q0FDN0I7O0FBRUQ7SUFDSSxlQUFlO0lBQ2YsMENBQTBDO0lBQzFDLFlBQVk7SUFDWixjQUFjO0lBQ2QsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtJQUNoQiw2RUFBNkU7SUFDN0Usb0JBQW9CO0NBQ3ZCOztBQUVEO0NBQ0MsaUJBQWlCO0NBQ2pCLDZCQUE2QjtDQUM3QixtQkFBbUI7Q0FDbkI7OENBQzZDO0NBQzdDOztBQUVEO0VBQ0UsZ0JBQWdCO0VBQ2hCLGFBQWE7RUFDYixhQUFhO0VBQ2IsVUFBVTtFQUNWLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIseUJBQXlCO0VBQ3pCLHFCQUFxQjtFQUNyQixxQkFBcUI7RUFDckIsZUFBZTtFQUNmLHlCQUF5QjtFQUN6QixzQkFBaUI7T0FBakIsaUJBQWlCO0VBQ2pCLG9DQUFvQztFQUNwQyxtQ0FBbUM7RUFDbkMsMENBQTBDO0VBQzFDLDZFQUE2RTtDQUM5RTs7QUFFRDtDQUNDLG1CQUFtQjtDQUNuQixpQkFBaUI7Q0FDakIsZUFBZTtDQUNmOztBQUVEO0NBQ0MsbUJBQW1CO0NBQ25CLGNBQWM7Q0FDZCxpQkFBaUI7Q0FDakIsbUJBQW1CO0NBQ25CLG1CQUFtQjtDQUNuQixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLCtCQUErQjtDQUMvQiwyQ0FBMkM7Q0FDM0Msd0NBQXdDO0NBQ3hDLG1DQUFtQztDQUNuQzs7QUFFRDtDQUNDLGNBQWM7Q0FDZDs7QUFFRDs7Q0FFQyxtQkFBbUI7Q0FDbkIsVUFBVTtDQUNWLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIscUJBQXFCO0NBQ3JCLHFCQUFxQjtDQUNyQixtQkFBbUI7Q0FDbkIsVUFBVTtDQUNWLGVBQWU7Q0FDZixhQUFhO0NBQ2IsdUJBQXVCO0NBQ3ZCLGtEQUFrRDtDQUNsRCx1QkFBdUI7Q0FDdkIsb0NBQW9DO0NBQ3BDLG1DQUFtQztDQUNuQzs7QUFFRDtDQUNDLDZCQUE2QjtDQUM3QixhQUFhO0NBQ2IsaUNBQWlDO0NBQ2pDLDhDQUE4QztDQUM5Qzs7QUFFRDtDQUNDLG1CQUFtQjtDQUNuQixXQUFXO0NBQ1gsOEJBQThCO0NBQzlCOztBQUVEO0NBQ0MsVUFBVTtDQUNWLFdBQVc7Q0FDWCxpQkFBaUI7Q0FDakI7O0FBRUQ7Q0FDQyxtQkFBbUI7Q0FDbkIsZ0JBQWdCO0NBQ2hCLGlDQUFpQztDQUNqQzs7QUFFRDtDQUNDLG9CQUFvQjtDQUNwQjs7QUFFRDtDQUNDLG9CQUFvQjtDQUNwQixXQUFXO0NBQ1gsZ0JBQWdCO0NBQ2hCOztBQUVEO0NBQ0MsZUFBZTtDQUNmLGFBQWE7Q0FDYixtQkFBbUI7Q0FDbkIsbUJBQW1CO0NBQ25COztBQUlEO0NBQ0MseUJBQXlCO0tBQ3JCLHNCQUFzQjtLQUN0QixpQkFBaUI7S0FDakIsc0JBQXNCO0tBQ3RCLG1CQUFtQjtLQUNuQiwwQkFBMEI7S0FDMUIsWUFBWTtFQUNmLFVBQVU7RUFDVixXQUFXO0tBQ1IsYUFBYTtLQUNiLFlBQVk7S0FDWixVQUFVO0VBQ2Isb0JBQW9CO0tBQ2pCLGdCQUFnQjtLQUNoQixjQUFjO0NBQ2xCOztBQUVEO0NBQ0MsMEJBQTBCO0NBQzFCOztBQUVEOztLQUVLLDBCQUEwQjtDQUM5Qjs7QUFFRDtDQUNDLG1CQUFtQjtDQUNuQixtQ0FBbUM7Q0FDbkMsb0JBQW9CO0NBQ3BCLFVBQVU7Q0FDVixVQUFVO0lBQ1Asa0JBQWtCO0lBQ2xCLGlDQUF5QjtZQUF6Qix5QkFBeUI7Q0FDNUI7O0FBRUQ7Q0FDQyxzQkFBc0I7Q0FDdEIsNkJBQTZCO0NBQzdCLGtCQUFrQjtDQUNsQixlQUFlO0NBQ2YsaUJBQWlCO0NBQ2pCLHVCQUF1QjtDQUN2Qjs7QUFFRDtDQUNDLGVBQWU7Q0FDZiw4QkFBOEI7Q0FDOUI7O0FBRUQ7Q0FDQyxjQUFjO0NBQ2QsbUJBQW1CO0NBQ25CLE9BQU87Q0FDUCxZQUFZO0NBQ1osVUFBVTtDQUNWLFlBQVk7Q0FDWixhQUFhO0NBQ2IsVUFBVTtDQUNWLGdCQUFnQjtDQUNoQixlQUFlO0NBQ2Ysb0JBQW9CO0NBQ3BCLGdDQUFnQztDQUNoQzs7QUFFRDtDQUNDLGVBQWU7Q0FDZjs7QUFFRDtDQUNDLGFBQWE7Q0FDYjs7QUFFRDtDQUNDLGVBQWU7Q0FDZjs7QUFFRDtDQUNDLGNBQWM7Q0FDZDs7QUFFRDtDQUNDLFlBQVk7Q0FDWixtQkFBbUI7Q0FDbkIsYUFBYTtDQUNiLG1CQUFtQjtDQUNuQiw4QkFBOEI7Q0FDOUI7O0FBRUQ7Q0FDQyxZQUFZO0NBQ1osbUJBQW1CO0NBQ25CLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsUUFBUTtDQUNSLGFBQWE7Q0FDYixpQkFBaUI7Q0FDakI7Ozs7Z0RBSStDO0NBQy9DOztBQUVEO0NBQ0MsWUFBWTtDQUNaLGlCQUFpQjtDQUNqQjs7QUFFRDtDQUNDLGlCQUFpQjtDQUNqQjs7QUFFRDtDQUNDLGVBQWU7Q0FDZixtQkFBbUI7Q0FDbkIsMENBQTBDO0NBQzFDLG9CQUFvQjtDQUNwQixtQkFBbUI7Q0FDbkIsZ0JBQWdCO0NBQ2hCLGdCQUFnQjtDQUNoQixVQUFVO0NBQ1YsZUFBZTtDQUNmLDZFQUE2RTtDQUM3RTs7QUFFRDtDQUNDLFVBQVU7Q0FDVixXQUFXO0NBQ1gsVUFBVTtDQUNWLGlCQUFpQjtDQUNqQixnQkFBZ0I7Q0FDaEIseUJBQXlCO0NBQ3pCLHFCQUFxQjtDQUNyQixxQkFBcUI7Q0FDckIsZUFBZTtDQUNmLHlCQUF5QjtDQUN6QixzQkFBaUI7TUFBakIsaUJBQWlCO0NBQ2pCLG9DQUFvQztDQUNwQyxtQ0FBbUM7Q0FDbkM7O0FBRUQ7SUFDSSxpQkFBaUI7SUFDakIsNEJBQTRCO0lBQzVCLG1CQUFtQjtJQUNuQjtpREFDNkM7Q0FDaEQ7O0FBQ0Q7SUFDSSxhQUFhO0NBQ2hCOztBQUVEO0NBQ0MsbUJBQW1CO0NBQ25CLFlBQVk7Q0FDWixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLCtCQUErQjtDQUMvQiwyQ0FBMkM7Q0FDM0Msd0NBQXdDO0NBQ3hDLG1DQUFtQztDQUNuQzs7QUFFRDtJQUNJLGdCQUFnQjtDQUNuQixhQUFhO0NBQ2IsYUFBYTtDQUNiLFVBQVU7Q0FDVixpQkFBaUI7Q0FDakIsZ0JBQWdCO0NBQ2hCLHlCQUF5QjtDQUN6QixxQkFBcUI7Q0FDckIscUJBQXFCO0NBQ3JCLGVBQWU7Q0FDZix5QkFBeUI7Q0FDekIsc0JBQWlCO01BQWpCLGlCQUFpQjtDQUNqQixvQ0FBb0M7SUFDakMsbUNBQW1DO0lBQ25DLDBDQUEwQztJQUMxQyw2RUFBNkU7Q0FDaEY7O0FBRUQ7Q0FDQyxrQkFBa0I7Q0FDbEI7O0FBRUQ7SUFDSSxhQUFhO0NBQ2hCLGtCQUFrQjtDQUNsQixtQkFBbUI7Q0FDbkI7O0FBRUQ7SUFDSSxnQkFBZ0I7Q0FDbkIsYUFBYTtDQUNiLGFBQWE7Q0FDYixVQUFVO0NBQ1YsaUJBQWlCO0NBQ2pCLGdCQUFnQjtDQUNoQix5QkFBeUI7Q0FDekIscUJBQXFCO0NBQ3JCLHFCQUFxQjtDQUNyQixlQUFlO0NBQ2YseUJBQXlCO0NBQ3pCLHNCQUFpQjtNQUFqQixpQkFBaUI7Q0FDakIsb0NBQW9DO0lBQ2pDLG1DQUFtQztJQUNuQywwQ0FBMEM7SUFDMUMsNkVBQTZFO0NBQ2hGOztBQUVEO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtDQUNyQjs7QUFFRDtDQUNDLGtCQUFrQjtDQUNsQixtQkFBbUI7Q0FDbkI7O0FBRUQ7Q0FDQyxrQkFBa0I7Q0FDbEIsaUJBQWlCO0NBQ2pCLHNCQUFzQjtDQUN0QixtQkFBbUI7Q0FDbkIsWUFBWTs7Q0FFWjs7QUFFRDtDQUNDLGVBQWU7Q0FDZixrQkFBa0I7Q0FDbEIsbUJBQW1CO0NBQ25CLGNBQWM7Q0FDZCxhQUFhO0NBQ2IsZ0JBQWdCOztDQUVoQjs7QUFFRDtDQUNDLGFBQWE7Q0FDYjs7QUFFRDtDQUNDLGNBQWM7R0FDWixnQkFBZ0IsQ0FBQyxtQkFBbUI7R0FDcEMsV0FBVyxDQUFDLGdCQUFnQjtHQUM1QixtQkFBbUIsQ0FBQyx5QkFBeUI7R0FDN0MsYUFBYTtHQUNiLFdBQVc7R0FDWCxZQUFZO0dBQ1osZUFBZSxDQUFDLDZCQUE2QjtHQUM3Qyw2QkFBNkIsQ0FBQyxvQkFBb0I7R0FDbEQsa0NBQWtDLENBQUMsc0JBQXNCO0NBQzNEOztBQUVEO0NBQ0MsYUFBYTtDQUNiLGVBQWU7Q0FDZixXQUFXO0NBQ1gsaUJBQWlCO0NBQ2pCOztBQUVEO0NBQ0MsbUJBQW1CO0NBQ25CLFVBQVU7Q0FDVixZQUFZO0NBQ1osZUFBZTtDQUNmLGdCQUFnQjtDQUNoQixrQkFBa0I7Q0FDbEIsaUJBQWlCO0dBQ2Y7O0FBRUg7O0NBRUMsWUFBWTtDQUNaLHNCQUFzQjtDQUN0QixnQkFBZ0I7Q0FDaEI7O0FBRUQ7Q0FDQyxtQkFBbUI7Q0FDbkIsVUFBVTtDQUNWLG1CQUFtQjtDQUNuQixrQkFBa0I7Q0FDbEIsZUFBZTtDQUNmLGdCQUFnQjtDQUNoQixrQkFBa0I7Q0FDbEIsaUJBQWlCO0dBQ2Y7O0FBRUg7O0NBRUMsc0JBQXNCO0NBQ3RCLHNCQUFzQjtDQUN0QixnQkFBZ0I7Q0FDaEI7O0FBRUQ7Q0FDQyxjQUFjO0dBQ1osZ0JBQWdCLENBQUMsbUJBQW1CO0dBQ3BDLFdBQVcsQ0FBQyxnQkFBZ0I7R0FDNUIsa0JBQWtCLENBQUMseUJBQXlCO0NBQzlDLGlCQUFpQjtDQUNqQixtQkFBbUI7Q0FDbkIsa0JBQWtCO0dBQ2hCLGFBQWE7R0FDYixjQUFjO0NBQ2hCLHFDQUFxQyxDQUFDLG9CQUFvQjtDQUMxRCw2RUFBNkU7O0NBRTdFOztBQUNEO0NBQ0Msa0JBQWtCO0NBQ2xCLGdCQUFnQjtDQUNoQix3QkFBd0I7O0NBRXhCOztBQUNEO0NBQ0MsZ0JBQWdCO0NBQ2hCLHVCQUF1QjtDQUN2QixVQUFVO0NBQ1YsYUFBYTtDQUNiLGlCQUFpQjtDQUNqQixnQkFBZ0I7Q0FDaEIseUJBQXlCO0NBQ3pCLHFCQUFxQjtDQUNyQixrQkFBa0I7Q0FDbEIsZUFBZTtDQUNmLHlCQUF5QjtDQUN6QixzQkFBaUI7TUFBakIsaUJBQWlCO0NBQ2pCLG9DQUFvQztDQUNwQyxtQ0FBbUM7Q0FDbkMsMENBQTBDO0NBQzFDLDZFQUE2RTtDQUM3RTs7QUFDRDtDQUNDLGNBQWM7Q0FDZCxpQkFBaUI7Q0FDakIsOEJBQThCOztDQUU5QiIsImZpbGUiOiJzcmMvc3R5bGVzLmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWdpc3Rlci13cmFwcGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgaGVpZ2h0OiAxMDB2aDtcbn1cbiAgXG4ucmVnaXN0ZXItd3JhcHBlciBoMXtcbiAgICBmb250LXNpemU6IDEwMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiAxMDA7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiByZ2JhKDE3NSwgNDcsIDQ3LCAwLjE1KTtcbiAgICAtd2Via2l0LXRleHQtcmVuZGVyaW5nOiBvcHRpbWl6ZUxlZ2liaWxpdHk7XG4gICAgLW1vei10ZXh0LXJlbmRlcmluZzogb3B0aW1pemVMZWdpYmlsaXR5O1xuICAgIHRleHQtcmVuZGVyaW5nOiBvcHRpbWl6ZUxlZ2liaWxpdHk7XG59XG4gIFxuLnJlZ2lzdGVyLXdyYXBwZXIgaW5wdXQge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4wMDMpO1xuICAgIGJveC1zaGFkb3c6IGluc2V0IDAgLTJweCAxcHggcmdiYSgwLCAwLCAwLCAwLjAzKTtcbiAgICBtYXJnaW46IDAgMCAxNnB4IDA7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGJvcmRlci1sZWZ0OiAycHggc29saWQgdHJhbnNwYXJlbnQ7XG59XG4gIFxuLnJlZ2lzdGVyLXdyYXBwZXIgaW5wdXQ6Oi13ZWJraXQtaW5wdXQtcGxhY2Vob2xkZXIge1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICBmb250LXdlaWdodDogMzAwO1xuICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG59XG4gIFxuLnJlZ2lzdGVyLXdyYXBwZXIgYnV0dG9uIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDE3NSwgNDcsIDQ3LCAwLjE1KTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAxNnB4O1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm94LXNoYWRvdzogMCAycHggNHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDI1cHggNTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgICBtYXJnaW4tYm90dG9tOiA2NHB4O1xufVxuXG4uc2lnbi1pbi13cmFwcGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgaGVpZ2h0OiAxMDB2aDtcbn1cbiAgXG4uc2lnbi1pbi13cmFwcGVyIGgxe1xuICAgIGZvbnQtc2l6ZTogMTAwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDEwMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6IHJnYmEoMTc1LCA0NywgNDcsIDAuMTUpO1xuICAgIC13ZWJraXQtdGV4dC1yZW5kZXJpbmc6IG9wdGltaXplTGVnaWJpbGl0eTtcbiAgICAtbW96LXRleHQtcmVuZGVyaW5nOiBvcHRpbWl6ZUxlZ2liaWxpdHk7XG4gICAgdGV4dC1yZW5kZXJpbmc6IG9wdGltaXplTGVnaWJpbGl0eTtcbn1cbiAgXG4uc2lnbi1pbi13cmFwcGVyIGlucHV0IHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAxNnB4O1xuICAgIGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMDAzKTtcbiAgICBib3gtc2hhZG93OiBpbnNldCAwIC0ycHggMXB4IHJnYmEoMCwgMCwgMCwgMC4wMyk7XG4gICAgbWFyZ2luOiAwIDAgMTZweCAwO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBib3JkZXItbGVmdDogMnB4IHNvbGlkIHRyYW5zcGFyZW50O1xufVxuICBcbi5zaWduLWluLXdyYXBwZXIgaW5wdXQ6Oi13ZWJraXQtaW5wdXQtcGxhY2Vob2xkZXIge1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICBmb250LXdlaWdodDogMzAwO1xuICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG59XG4gIFxuLnNpZ24taW4td3JhcHBlciBidXR0b24ge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMTc1LCA0NywgNDcsIDAuMTUpO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBib3gtc2hhZG93OiAwIDJweCA0cHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgMjVweCA1MHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xuICAgIG1hcmdpbi1ib3R0b206IDY0cHg7XG59XG5cbi50b2RvYXBwIHtcblx0YmFja2dyb3VuZDogI2ZmZjtcblx0bWFyZ2luOiAxNTBweCA1MHB4IDQwcHggNTBweDtcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRib3gtc2hhZG93OiAwIDJweCA0cHggMCByZ2JhKDAsIDAsIDAsIDAuMiksXG5cdCAgICAgICAgICAgIDAgMjVweCA1MHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xufVxuXG4udG9kb2FwcCAudGFzay1idXR0b24ge1xuXHRcdGN1cnNvcjogcG9pbnRlcjtcblx0XHRtYXJnaW46IDEwcHg7XG5cdFx0cGFkZGluZzogNXB4O1xuXHRcdGJvcmRlcjogMDtcblx0XHRiYWNrZ3JvdW5kOiBub25lO1xuXHRcdGZvbnQtc2l6ZTogMTAwJTtcblx0XHR2ZXJ0aWNhbC1hbGlnbjogYmFzZWxpbmU7XG5cdFx0Zm9udC1mYW1pbHk6IGluaGVyaXQ7XG5cdFx0Zm9udC13ZWlnaHQ6IGluaGVyaXQ7XG5cdFx0Y29sb3I6IGluaGVyaXQ7XG5cdFx0LXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuXHRcdGFwcGVhcmFuY2U6IG5vbmU7XG5cdFx0LXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XG5cdFx0LW1vei1vc3gtZm9udC1zbW9vdGhpbmc6IGdyYXlzY2FsZTtcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDE3NSwgNDcsIDQ3LCAwLjE1KTtcblx0XHRib3gtc2hhZG93OiAwIDJweCA0cHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgMjVweCA1MHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xufVxuXG4udG9kb2FwcCAuaW5wdXQgaW5wdXQ6Oi13ZWJraXQtaW5wdXQtcGxhY2Vob2xkZXIge1xuXHRmb250LXN0eWxlOiBpdGFsaWM7XG5cdGZvbnQtd2VpZ2h0OiAzMDA7XG5cdGNvbG9yOiAjZTZlNmU2O1xufVxuXG4udG9kb2FwcCAuaW5wdXQgaDEge1xuXHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdGRpc3BsYXk6YmxvY2s7XG5cdG1hcmdpbi1sZWZ0OiA0MCU7XG5cdG1hcmdpbi1yaWdodDogYXV0bztcblx0bWFyZ2luLXRvcDogLTE1MHB4O1xuXHRmb250LXNpemU6IDEwMHB4O1xuXHRmb250LXdlaWdodDogMTAwO1xuXHRjb2xvcjogcmdiYSgxNzUsIDQ3LCA0NywgMC4xNSk7XG5cdC13ZWJraXQtdGV4dC1yZW5kZXJpbmc6IG9wdGltaXplTGVnaWJpbGl0eTtcblx0LW1vei10ZXh0LXJlbmRlcmluZzogb3B0aW1pemVMZWdpYmlsaXR5O1xuXHR0ZXh0LXJlbmRlcmluZzogb3B0aW1pemVMZWdpYmlsaXR5O1xufVxuXG4udG9kb2FwcCBoMS5lZGl0aW5nIHtcblx0ZGlzcGxheTogbm9uZTtcbn1cblxuLm5ldy10b2RvLFxuLmVkaXQge1xuXHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdG1hcmdpbjogMDtcblx0d2lkdGg6IDEwMCU7XG5cdGZvbnQtc2l6ZTogMjhweDtcblx0Zm9udC1mYW1pbHk6IGluaGVyaXQ7XG5cdGZvbnQtd2VpZ2h0OiBpbmhlcml0O1xuXHRsaW5lLWhlaWdodDogMS40ZW07XG5cdGJvcmRlcjogMDtcblx0Y29sb3I6IGluaGVyaXQ7XG5cdHBhZGRpbmc6IDZweDtcblx0Ym9yZGVyOiAxcHggc29saWQgIzk5OTtcblx0Ym94LXNoYWRvdzogaW5zZXQgMCAtMXB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4yKTtcblx0Ym94LXNpemluZzogYm9yZGVyLWJveDtcblx0LXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XG5cdC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XG59XG5cbi5uZXctdG9kbyB7XG5cdHBhZGRpbmc6IDE2cHggMTZweCAxNnB4IDYwcHg7XG5cdGJvcmRlcjogbm9uZTtcblx0YmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjAwMyk7XG5cdGJveC1zaGFkb3c6IGluc2V0IDAgLTJweCAxcHggcmdiYSgwLDAsMCwwLjAzKTtcbn1cblxuLm1haW4ge1xuXHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdHotaW5kZXg6IDI7XG5cdGJvcmRlci10b3A6IDFweCBzb2xpZCAjZTZlNmU2O1xufVxuXG4udG9kby1saXN0IHtcblx0bWFyZ2luOiAwO1xuXHRwYWRkaW5nOiAwO1xuXHRsaXN0LXN0eWxlOiBub25lO1xufVxuXG4udG9kby1saXN0IGxpIHtcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRmb250LXNpemU6IDI4cHg7XG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWRlZGVkO1xufVxuXG4udG9kby1saXN0IGxpOmxhc3QtY2hpbGQge1xuXHRib3JkZXItYm90dG9tOiBub25lO1xufVxuXG4udG9kby1saXN0IGxpLmVkaXRpbmcge1xuXHRib3JkZXItYm90dG9tOiBub25lO1xuXHRwYWRkaW5nOiAwO1xuXHRmb250LXNpemU6IDIxcHg7XG59XG5cbi50b2RvLWxpc3QgbGkuZWRpdGluZyAuZWRpdCB7XG5cdGRpc3BsYXk6IGJsb2NrO1xuXHR3aWR0aDogNjUwcHg7XG5cdHBhZGRpbmc6IDEycHggMTZweDtcblx0bWFyZ2luOiAwIDAgMCA0M3B4O1xufVxuXG5cblxuLnRvZG8tbGlzdCBsaSAudG9nZ2xlIHtcblx0LXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuICAgICAtbW96LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgIGFwcGVhcmFuY2U6IG5vbmU7XG4gICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMWYxO1xuICAgICBjb2xvcjogIzY2Njtcblx0IHRvcDogMTVweDtcblx0IGxlZnQ6IDIwcHg7XG4gICAgIGhlaWdodDogNDBweDtcbiAgICAgd2lkdGg6IDQwcHg7XG4gICAgIGJvcmRlcjogMDtcblx0IGJvcmRlci1yYWRpdXM6IDcwcHg7XG4gICAgIGN1cnNvcjogcG9pbnRlcjsgXG4gICAgIG91dGxpbmU6IG5vbmU7XG59XG5cbi50b2RvLWxpc3QgbGkgLnRvZ2dsZTpjaGVja2VkIHtcblx0YmFja2dyb3VuZC1jb2xvcjogI2YxZjFmMTtcbn1cblxuLnRvZG8tbGlzdCBsaSAudG9nZ2xlOmhvdmVyXG57XG4gICAgIGJhY2tncm91bmQtY29sb3I6ICNmN2Y3Zjc7XG59XG5cbi50b2RvLWxpc3QgbGkgLnRvZ2dsZTpjaGVja2VkOjpiZWZvcmUge1xuXHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdGZvbnQ6IDM1cHggJ09wZW4gU2FucycsIHNhbnMtc2VyaWY7XG5cdGZvbnQtd2VpZ2h0OiBib2xkZXI7XG5cdGxlZnQ6IDlweDtcblx0dG9wOiAtM3B4O1xuICAgIGNvbnRlbnQ6ICdcXDAyMTQzJztcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSg0MGRlZyk7XG59XG5cbi50b2RvLWxpc3QgbGkgbGFiZWwge1xuXHR3b3JkLWJyZWFrOiBicmVhay1hbGw7XG5cdHBhZGRpbmc6IDE1cHggNjBweCAxNXB4IDE1cHg7XG5cdG1hcmdpbi1sZWZ0OiA2NXB4O1xuXHRkaXNwbGF5OiBibG9jaztcblx0bGluZS1oZWlnaHQ6IDEuMjtcblx0dHJhbnNpdGlvbjogY29sb3IgMC40cztcbn1cblxuLnRvZG8tbGlzdCBsaS5jb21wbGV0ZWQgbGFiZWwge1xuXHRjb2xvcjogI2Q5ZDlkOTtcblx0dGV4dC1kZWNvcmF0aW9uOiBsaW5lLXRocm91Z2g7XG59XG5cbi50b2RvLWxpc3QgbGkgLmRlc3Ryb3kge1xuXHRkaXNwbGF5OiBub25lO1xuXHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdHRvcDogMDtcblx0cmlnaHQ6IDEwcHg7XG5cdGJvdHRvbTogMDtcblx0d2lkdGg6IDQwcHg7XG5cdGhlaWdodDogNDBweDtcblx0bWFyZ2luOiAwO1xuXHRmb250LXNpemU6IDQ1cHg7XG5cdGNvbG9yOiAjY2M5YTlhO1xuXHRtYXJnaW4tYm90dG9tOiAxMXB4O1xuXHR0cmFuc2l0aW9uOiBjb2xvciAwLjJzIGVhc2Utb3V0O1xufVxuXG4udG9kby1saXN0IGxpIC5kZXN0cm95OmhvdmVyIHtcblx0Y29sb3I6ICNhZjViNWU7XG59XG5cbi50b2RvLWxpc3QgbGkgLmRlc3Ryb3k6YWZ0ZXIge1xuXHRjb250ZW50OiAnw5cnO1xufVxuXG4udG9kby1saXN0IGxpOmhvdmVyIC5kZXN0cm95IHtcblx0ZGlzcGxheTogYmxvY2s7XG59XG5cbi50b2RvLWxpc3QgLmVkaXQge1xuXHRkaXNwbGF5OiBub25lO1xufVxuXG4uZm9vdGVyIHtcblx0Y29sb3I6ICM3Nzc7XG5cdHBhZGRpbmc6IDEwcHggMTVweDtcblx0aGVpZ2h0OiA1MHB4O1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdGJvcmRlci10b3A6IDFweCBzb2xpZCAjZTZlNmU2O1xufVxuXG4uZm9vdGVyOmJlZm9yZSB7XG5cdGNvbnRlbnQ6ICcnO1xuXHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdHJpZ2h0OiAwO1xuXHRib3R0b206IDA7XG5cdGxlZnQ6IDA7XG5cdGhlaWdodDogNTBweDtcblx0b3ZlcmZsb3c6IGhpZGRlbjtcblx0Ym94LXNoYWRvdzogMCAxcHggMXB4IHJnYmEoMCwgMCwgMCwgMC4yKSxcblx0ICAgICAgICAgICAgMCA4cHggMCAtM3B4ICNmNmY2ZjYsXG5cdCAgICAgICAgICAgIDAgOXB4IDFweCAtM3B4IHJnYmEoMCwgMCwgMCwgMC4yKSxcblx0ICAgICAgICAgICAgMCAxNnB4IDAgLTZweCAjZjZmNmY2LFxuXHQgICAgICAgICAgICAwIDE3cHggMnB4IC02cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xufVxuXG4udG9kby1jb3VudCB7XG5cdGZsb2F0OiBsZWZ0O1xuXHR0ZXh0LWFsaWduOiBsZWZ0O1xufVxuXG4udG9kby1jb3VudCBzdHJvbmcge1xuXHRmb250LXdlaWdodDogMzAwO1xufVxuXG4uc2lnbi1vdXQge1xuXHRkaXNwbGF5OiBibG9jaztcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDE3NSwgNDcsIDQ3LCAwLjE1KTtcblx0cGFkZGluZzogMTRweCAxMDBweDtcblx0bWFyZ2luOiAxMDBweCBhdXRvO1xuXHRmb250LXNpemU6IDIwcHg7XG5cdGN1cnNvcjogcG9pbnRlcjtcblx0Ym9yZGVyOiAwO1xuXHRjb2xvcjogaW5oZXJpdDtcblx0Ym94LXNoYWRvdzogMCAycHggNHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDI1cHggNTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbn1cblxuLnRvZG8tbGlzdCBidXR0b24ge1xuXHRtYXJnaW46IDA7XG5cdHBhZGRpbmc6IDA7XG5cdGJvcmRlcjogMDtcblx0YmFja2dyb3VuZDogbm9uZTtcblx0Zm9udC1zaXplOiAxMDAlO1xuXHR2ZXJ0aWNhbC1hbGlnbjogYmFzZWxpbmU7XG5cdGZvbnQtZmFtaWx5OiBpbmhlcml0O1xuXHRmb250LXdlaWdodDogaW5oZXJpdDtcblx0Y29sb3I6IGluaGVyaXQ7XG5cdC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcblx0YXBwZWFyYW5jZTogbm9uZTtcblx0LXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XG5cdC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XG59XG5cbi5wcm9maWxlIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIG1hcmdpbjogNTBweCA1MHB4IDQwcHggNTBweDtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgYm94LXNoYWRvdzogMCAycHggNHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLFxuICAgICAgICAgICAgICAgIDAgMjVweCA1MHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xufVxuLnByb2ZpbGUgLmlucHV0e1xuICAgIG1hcmdpbjogMTBweDtcbn1cblxuLnByb2ZpbGUgLmlucHV0IGgxIHtcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHR3aWR0aDogMTAwJTtcblx0Zm9udC1zaXplOiAxMDBweDtcblx0Zm9udC13ZWlnaHQ6IDEwMDtcblx0Y29sb3I6IHJnYmEoMTc1LCA0NywgNDcsIDAuMTUpO1xuXHQtd2Via2l0LXRleHQtcmVuZGVyaW5nOiBvcHRpbWl6ZUxlZ2liaWxpdHk7XG5cdC1tb3otdGV4dC1yZW5kZXJpbmc6IG9wdGltaXplTGVnaWJpbGl0eTtcblx0dGV4dC1yZW5kZXJpbmc6IG9wdGltaXplTGVnaWJpbGl0eTtcbn1cblxuLnByb2ZpbGUgYnV0dG9uIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG5cdG1hcmdpbjogMTBweDtcblx0cGFkZGluZzogNXB4O1xuXHRib3JkZXI6IDA7XG5cdGJhY2tncm91bmQ6IG5vbmU7XG5cdGZvbnQtc2l6ZTogMTAwJTtcblx0dmVydGljYWwtYWxpZ246IGJhc2VsaW5lO1xuXHRmb250LWZhbWlseTogaW5oZXJpdDtcblx0Zm9udC13ZWlnaHQ6IGluaGVyaXQ7XG5cdGNvbG9yOiBpbmhlcml0O1xuXHQtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG5cdGFwcGVhcmFuY2U6IG5vbmU7XG5cdC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkO1xuICAgIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgxNzUsIDQ3LCA0NywgMC4xNSk7XG4gICAgYm94LXNoYWRvdzogMCAycHggNHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDI1cHggNTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbn1cblxuLmNyZWF0b3ItZGlzcGxheSB7XG5cdG1hcmdpbi1sZWZ0OiA1MHB4O1xufVxuXG4ubmF2IHtcbiAgICBmbG9hdDogcmlnaHQ7XG5cdG1hcmdpbi10b3A6IC01MHB4O1xuXHRtYXJnaW4tcmlnaHQ6IDQwcHg7XG59XG5cbi5uYXYgYnV0dG9uIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG5cdG1hcmdpbjogMTBweDtcblx0cGFkZGluZzogNXB4O1xuXHRib3JkZXI6IDA7XG5cdGJhY2tncm91bmQ6IG5vbmU7XG5cdGZvbnQtc2l6ZTogMTAwJTtcblx0dmVydGljYWwtYWxpZ246IGJhc2VsaW5lO1xuXHRmb250LWZhbWlseTogaW5oZXJpdDtcblx0Zm9udC13ZWlnaHQ6IGluaGVyaXQ7XG5cdGNvbG9yOiBpbmhlcml0O1xuXHQtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG5cdGFwcGVhcmFuY2U6IG5vbmU7XG5cdC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkO1xuICAgIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgxNzUsIDQ3LCA0NywgMC4xNSk7XG4gICAgYm94LXNoYWRvdzogMCAycHggNHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDI1cHggNTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbn1cblxuLm5hdiBwIHtcbiAgICBtYXJnaW46IDE1cHggNXB4O1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4udGFzayB7XG5cdG1hcmdpbi1sZWZ0OiAxMHB4O1xuXHRtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi50YXNrIC5pbWFnZS1maWVsZHtcblx0cGFkZGluZy1yaWdodDozcHg7IFxuXHRwYWRkaW5nLXRvcDogM3B4OyBcblx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRwb3NpdGlvbjogcmVsYXRpdmU7XG5cdG1hcmdpbjozMHB4O1xuXHRcbn1cblxuLnRhc2sgaW1ne1xuXHRkaXNwbGF5OiBibG9jaztcblx0bWFyZ2luLWxlZnQ6IGF1dG87IFxuXHRtYXJnaW4tcmlnaHQ6IGF1dG87IFxuXHRoZWlnaHQ6IDI1MHB4O1xuXHR3aWR0aDogMjUwcHg7XG5cdGN1cnNvcjogcG9pbnRlcjtcblx0XG59XG5cbi50YXNrIGltZzpob3ZlciB7XG5cdG9wYWNpdHk6IDAuNztcbn1cblxuLm1vZGFsIHtcblx0ZGlzcGxheTpibG9jaztcbiAgXHRwb3NpdGlvbjogZml4ZWQ7IC8qIFN0YXkgaW4gcGxhY2UgKi9cbiAgXHR6LWluZGV4OiAxOyAvKiBTaXQgb24gdG9wICovXG4gIFx0cGFkZGluZy10b3A6IDEwMHB4OyAvKiBMb2NhdGlvbiBvZiB0aGUgYm94ICovXG4gIFx0bWFyZ2luOiBhdXRvO1xuICBcdHdpZHRoOiA5NSU7XG4gIFx0aGVpZ2h0OiA5NSU7XG4gIFx0b3ZlcmZsb3c6IGF1dG87IC8qIEVuYWJsZSBzY3JvbGwgaWYgbmVlZGVkICovXG4gIFx0YmFja2dyb3VuZC1jb2xvcjogcmdiKDAsMCwwKTsgLyogRmFsbGJhY2sgY29sb3IgKi9cbiAgXHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsMCwwLDAuOSk7IC8qIEJsYWNrIHcvIG9wYWNpdHkgKi9cbn1cblxuLm1vZGFsLWNvbnRlbnQge1xuXHRtYXJnaW46IGF1dG87XG5cdGRpc3BsYXk6IGJsb2NrO1xuXHR3aWR0aDogOTAlO1xuXHRtYXgtd2lkdGg6IDcwMHB4O1xufVxuXG4uY2xvc2Uge1xuXHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdHRvcDogMTVweDtcblx0cmlnaHQ6IDM1cHg7XG5cdGNvbG9yOiAjZjFmMWYxO1xuXHRmb250LXNpemU6IDQwcHg7XG5cdGZvbnQtd2VpZ2h0OiBib2xkO1xuXHR0cmFuc2l0aW9uOiAwLjNzO1xuICB9XG4gIFxuLmNsb3NlOmhvdmVyLFxuLmNsb3NlOmZvY3VzIHtcblx0Y29sb3I6ICNiYmI7XG5cdHRleHQtZGVjb3JhdGlvbjogbm9uZTtcblx0Y3Vyc29yOiBwb2ludGVyO1xufVxuXG4uZGVsZXRlIHtcblx0cG9zaXRpb246IGFic29sdXRlO1xuXHR0b3A6IDEwcHg7XG5cdG1hcmdpbi1sZWZ0OiAyMTBweDtcblx0bWFyZ2luLXRvcDogLTMwcHg7XG5cdGNvbG9yOiAjZjMyYTJhO1xuXHRmb250LXNpemU6IDUwcHg7XG5cdGZvbnQtd2VpZ2h0OiBib2xkO1xuXHR0cmFuc2l0aW9uOiAwLjNzO1xuICB9XG4gIFxuLmRlbGV0ZTpob3Zlcixcbi5kZWxldGU6Zm9jdXMge1xuXHRjb2xvcjogcmdiKDE1MSwgMiwgMik7XG5cdHRleHQtZGVjb3JhdGlvbjogbm9uZTtcblx0Y3Vyc29yOiBwb2ludGVyO1xufVxuXG4uZGVsZXRlLWFsZXJ0IHtcblx0ZGlzcGxheTpibG9jaztcbiAgXHRwb3NpdGlvbjogZml4ZWQ7IC8qIFN0YXkgaW4gcGxhY2UgKi9cbiAgXHR6LWluZGV4OiAxOyAvKiBTaXQgb24gdG9wICovXG4gIFx0cGFkZGluZy10b3A6IDIwcHg7IC8qIExvY2F0aW9uIG9mIHRoZSBib3ggKi9cblx0bWFyZ2luLWxlZnQ6IDE1JTtcblx0bWFyZ2luLXJpZ2h0OiBhdXRvO1xuXHRtYXJnaW4tdG9wOiAtMjBweDtcbiAgXHR3aWR0aDogNTAwcHg7XG4gIFx0aGVpZ2h0OiAyMDBweDtcblx0YmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwgMjUxLCAyNTEpOyAvKiBGYWxsYmFjayBjb2xvciAqL1xuXHRib3gtc2hhZG93OiAwIDJweCA0cHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgMjVweCA1MHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xuXG59XG4uZGVsZXRlLWFsZXJ0IHAge1xuXHRtYXJnaW4tbGVmdDogMTVweDtcblx0Zm9udC1zaXplOiAzMHB4O1xuXHRjb2xvcjogcmdiKDIwNywgMjksIDI5KTtcblxufVxuLmRlbGV0ZS1hbGVydCBidXR0b257XG5cdGN1cnNvcjogcG9pbnRlcjtcblx0cGFkZGluZzogMCAxMHB4IDAgMTBweDtcblx0Ym9yZGVyOiAwO1xuXHRtYXJnaW46IDE1cHg7XG5cdGJhY2tncm91bmQ6IG5vbmU7XG5cdGZvbnQtc2l6ZTogMTUwJTtcblx0dmVydGljYWwtYWxpZ246IGJhc2VsaW5lO1xuXHRmb250LWZhbWlseTogaW5oZXJpdDtcblx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdGNvbG9yOiBpbmhlcml0O1xuXHQtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG5cdGFwcGVhcmFuY2U6IG5vbmU7XG5cdC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkO1xuXHQtbW96LW9zeC1mb250LXNtb290aGluZzogZ3JheXNjYWxlO1xuXHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDE3NSwgNDcsIDQ3LCAwLjE1KTtcblx0Ym94LXNoYWRvdzogMCAycHggNHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDI1cHggNTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbn1cbi5kZWxldGUtYWxlcnQgLmJ1dHRvbnMge1xuXHRkaXNwbGF5OiBmbGV4O1xuXHRtYXJnaW4tdG9wOiAzNXB4O1xuXHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcblx0XG59Il19 */", '', '']]

/***/ }),

/***/ "./node_modules/style-loader/lib/addStyles.js":
/*!****************************************************!*\
  !*** ./node_modules/style-loader/lib/addStyles.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

var stylesInDom = {};

var	memoize = function (fn) {
	var memo;

	return function () {
		if (typeof memo === "undefined") memo = fn.apply(this, arguments);
		return memo;
	};
};

var isOldIE = memoize(function () {
	// Test for IE <= 9 as proposed by Browserhacks
	// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
	// Tests for existence of standard globals is to allow style-loader
	// to operate correctly into non-standard environments
	// @see https://github.com/webpack-contrib/style-loader/issues/177
	return window && document && document.all && !window.atob;
});

var getTarget = function (target, parent) {
  if (parent){
    return parent.querySelector(target);
  }
  return document.querySelector(target);
};

var getElement = (function (fn) {
	var memo = {};

	return function(target, parent) {
                // If passing function in options, then use it for resolve "head" element.
                // Useful for Shadow Root style i.e
                // {
                //   insertInto: function () { return document.querySelector("#foo").shadowRoot }
                // }
                if (typeof target === 'function') {
                        return target();
                }
                if (typeof memo[target] === "undefined") {
			var styleTarget = getTarget.call(this, target, parent);
			// Special case to return head of iframe instead of iframe itself
			if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
				try {
					// This will throw an exception if access to iframe is blocked
					// due to cross-origin restrictions
					styleTarget = styleTarget.contentDocument.head;
				} catch(e) {
					styleTarget = null;
				}
			}
			memo[target] = styleTarget;
		}
		return memo[target]
	};
})();

var singleton = null;
var	singletonCounter = 0;
var	stylesInsertedAtTop = [];

var	fixUrls = __webpack_require__(/*! ./urls */ "./node_modules/style-loader/lib/urls.js");

module.exports = function(list, options) {
	if (typeof DEBUG !== "undefined" && DEBUG) {
		if (typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};

	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (!options.singleton && typeof options.singleton !== "boolean") options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
        if (!options.insertInto) options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (!options.insertAt) options.insertAt = "bottom";

	var styles = listToStyles(list, options);

	addStylesToDom(styles, options);

	return function update (newList) {
		var mayRemove = [];

		for (var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];

			domStyle.refs--;
			mayRemove.push(domStyle);
		}

		if(newList) {
			var newStyles = listToStyles(newList, options);
			addStylesToDom(newStyles, options);
		}

		for (var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];

			if(domStyle.refs === 0) {
				for (var j = 0; j < domStyle.parts.length; j++) domStyle.parts[j]();

				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom (styles, options) {
	for (var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];

		if(domStyle) {
			domStyle.refs++;

			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}

			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];

			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}

			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles (list, options) {
	var styles = [];
	var newStyles = {};

	for (var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = options.base ? item[0] + options.base : item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};

		if(!newStyles[id]) styles.push(newStyles[id] = {id: id, parts: [part]});
		else newStyles[id].parts.push(part);
	}

	return styles;
}

function insertStyleElement (options, style) {
	var target = getElement(options.insertInto)

	if (!target) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}

	var lastStyleElementInsertedAtTop = stylesInsertedAtTop[stylesInsertedAtTop.length - 1];

	if (options.insertAt === "top") {
		if (!lastStyleElementInsertedAtTop) {
			target.insertBefore(style, target.firstChild);
		} else if (lastStyleElementInsertedAtTop.nextSibling) {
			target.insertBefore(style, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			target.appendChild(style);
		}
		stylesInsertedAtTop.push(style);
	} else if (options.insertAt === "bottom") {
		target.appendChild(style);
	} else if (typeof options.insertAt === "object" && options.insertAt.before) {
		var nextSibling = getElement(options.insertAt.before, target);
		target.insertBefore(style, nextSibling);
	} else {
		throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n");
	}
}

function removeStyleElement (style) {
	if (style.parentNode === null) return false;
	style.parentNode.removeChild(style);

	var idx = stylesInsertedAtTop.indexOf(style);
	if(idx >= 0) {
		stylesInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement (options) {
	var style = document.createElement("style");

	if(options.attrs.type === undefined) {
		options.attrs.type = "text/css";
	}

	if(options.attrs.nonce === undefined) {
		var nonce = getNonce();
		if (nonce) {
			options.attrs.nonce = nonce;
		}
	}

	addAttrs(style, options.attrs);
	insertStyleElement(options, style);

	return style;
}

function createLinkElement (options) {
	var link = document.createElement("link");

	if(options.attrs.type === undefined) {
		options.attrs.type = "text/css";
	}
	options.attrs.rel = "stylesheet";

	addAttrs(link, options.attrs);
	insertStyleElement(options, link);

	return link;
}

function addAttrs (el, attrs) {
	Object.keys(attrs).forEach(function (key) {
		el.setAttribute(key, attrs[key]);
	});
}

function getNonce() {
	if (false) {}

	return __webpack_require__.nc;
}

function addStyle (obj, options) {
	var style, update, remove, result;

	// If a transform function was defined, run it on the css
	if (options.transform && obj.css) {
	    result = typeof options.transform === 'function'
		 ? options.transform(obj.css) 
		 : options.transform.default(obj.css);

	    if (result) {
	    	// If transform returns a value, use that instead of the original css.
	    	// This allows running runtime transformations on the css.
	    	obj.css = result;
	    } else {
	    	// If the transform function returns a falsy value, don't add this css.
	    	// This allows conditional loading of css
	    	return function() {
	    		// noop
	    	};
	    }
	}

	if (options.singleton) {
		var styleIndex = singletonCounter++;

		style = singleton || (singleton = createStyleElement(options));

		update = applyToSingletonTag.bind(null, style, styleIndex, false);
		remove = applyToSingletonTag.bind(null, style, styleIndex, true);

	} else if (
		obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function"
	) {
		style = createLinkElement(options);
		update = updateLink.bind(null, style, options);
		remove = function () {
			removeStyleElement(style);

			if(style.href) URL.revokeObjectURL(style.href);
		};
	} else {
		style = createStyleElement(options);
		update = applyToTag.bind(null, style);
		remove = function () {
			removeStyleElement(style);
		};
	}

	update(obj);

	return function updateStyle (newObj) {
		if (newObj) {
			if (
				newObj.css === obj.css &&
				newObj.media === obj.media &&
				newObj.sourceMap === obj.sourceMap
			) {
				return;
			}

			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;

		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag (style, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (style.styleSheet) {
		style.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = style.childNodes;

		if (childNodes[index]) style.removeChild(childNodes[index]);

		if (childNodes.length) {
			style.insertBefore(cssNode, childNodes[index]);
		} else {
			style.appendChild(cssNode);
		}
	}
}

function applyToTag (style, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		style.setAttribute("media", media)
	}

	if(style.styleSheet) {
		style.styleSheet.cssText = css;
	} else {
		while(style.firstChild) {
			style.removeChild(style.firstChild);
		}

		style.appendChild(document.createTextNode(css));
	}
}

function updateLink (link, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/*
		If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
		and there is no publicPath defined then lets turn convertToAbsoluteUrls
		on by default.  Otherwise default to the convertToAbsoluteUrls option
		directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls) {
		css = fixUrls(css);
	}

	if (sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = link.href;

	link.href = URL.createObjectURL(blob);

	if(oldSrc) URL.revokeObjectURL(oldSrc);
}


/***/ }),

/***/ "./node_modules/style-loader/lib/urls.js":
/*!***********************************************!*\
  !*** ./node_modules/style-loader/lib/urls.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {


/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */

module.exports = function (css) {
  // get current location
  var location = typeof window !== "undefined" && window.location;

  if (!location) {
    throw new Error("fixUrls requires window.location");
  }

	// blank or null?
	if (!css || typeof css !== "string") {
	  return css;
  }

  var baseUrl = location.protocol + "//" + location.host;
  var currentDir = baseUrl + location.pathname.replace(/\/[^\/]*$/, "/");

	// convert each url(...)
	/*
	This regular expression is just a way to recursively match brackets within
	a string.

	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
	   (  = Start a capturing group
	     (?:  = Start a non-capturing group
	         [^)(]  = Match anything that isn't a parentheses
	         |  = OR
	         \(  = Match a start parentheses
	             (?:  = Start another non-capturing groups
	                 [^)(]+  = Match anything that isn't a parentheses
	                 |  = OR
	                 \(  = Match a start parentheses
	                     [^)(]*  = Match anything that isn't a parentheses
	                 \)  = Match a end parentheses
	             )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
	 \)  = Match a close parens

	 /gi  = Get all matches, not the first.  Be case insensitive.
	 */
	var fixedCss = css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function(fullMatch, origUrl) {
		// strip quotes (if they exist)
		var unquotedOrigUrl = origUrl
			.trim()
			.replace(/^"(.*)"$/, function(o, $1){ return $1; })
			.replace(/^'(.*)'$/, function(o, $1){ return $1; });

		// already a full url? no change
		if (/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(unquotedOrigUrl)) {
		  return fullMatch;
		}

		// convert the url to a full url
		var newUrl;

		if (unquotedOrigUrl.indexOf("//") === 0) {
		  	//TODO: should we add protocol?
			newUrl = unquotedOrigUrl;
		} else if (unquotedOrigUrl.indexOf("/") === 0) {
			// path should be relative to the base url
			newUrl = baseUrl + unquotedOrigUrl; // already starts with '/'
		} else {
			// path should be relative to current directory
			newUrl = currentDir + unquotedOrigUrl.replace(/^\.\//, ""); // Strip leading './'
		}

		// send back the fixed url(...)
		return "url(" + JSON.stringify(newUrl) + ")";
	});

	// send back the fixed css
	return fixedCss;
};


/***/ }),

/***/ "./src/styles.css":
/*!************************!*\
  !*** ./src/styles.css ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!../node_modules/postcss-loader/src??embedded!./styles.css */ "./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./src/styles.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ 2:
/*!******************************!*\
  !*** multi ./src/styles.css ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\example\todolist\website\src\styles.css */"./src/styles.css");


/***/ })

},[[2,"runtime"]]]);
//# sourceMappingURL=styles.js.map